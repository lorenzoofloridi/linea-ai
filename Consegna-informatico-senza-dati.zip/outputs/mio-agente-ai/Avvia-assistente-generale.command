#!/bin/zsh
exec "${0:A:h}/Avvia.command"
