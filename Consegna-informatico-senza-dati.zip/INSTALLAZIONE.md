# Consegna sorgenti — anteprima locale

Non contiene account, chat, database, credenziali Google, chiavi SMTP o modelli. È una copia sorgenti da installare, non un’app pronta da aprire senza preparazione.

Con Python compatibile con requirements.txt (verificato su 3.14) e Ollama installati, dalla radice:

    python3 -m venv outputs/mio-agente-ai/.venv
    outputs/mio-agente-ai/.venv/bin/python -m pip install -r outputs/mio-agente-ai/requirements.txt
    ollama pull qwen2.5:7b
    cd outputs/linea-ai-site
    ../mio-agente-ai/.venv/bin/python serve.py

Aprire http://127.0.0.1:8765/ e registrare un account di prova. Per Mac rendere eseguibili i file .command se il programma di estrazione non conserva i permessi. Consultare outputs/mio-agente-ai/README.md e la relativa cartella documentazione. Le configurazioni Google e gli archivi storici sono esclusi; i relativi avvii richiedono una configurazione separata. Non pubblicare questa anteprima senza completare i punti di produzione indicati.
