# Consegna sorgenti — anteprima locale

Non contiene account, chat, database, credenziali Google, chiavi SMTP o modelli. È una copia sorgenti da installare, non un’app pronta da aprire senza preparazione.

Con Python 3.14 e Ollama installati, dalla radice:

    python3 -X utf8 linea.py install
    ollama pull qwen2.5:7b
    python3 -X utf8 linea.py check
    python3 -X utf8 linea.py start

Su Windows usare py -3.14 al posto di python3, oppure Installa-Windows.bat e Avvia-Windows.bat. Non trasferire la .venv: ricrearla. L’installazione essenziale usa requirements-runtime.lock con hash. requirements.txt conserva le librerie dei percorsi storici opzionali.

Aprire http://127.0.0.1:8765/ e registrare un account di prova. Per Mac rendere eseguibili i file .command se il programma di estrazione non conserva i permessi. Consultare outputs/mio-agente-ai/README.md e la relativa cartella documentazione. Le configurazioni Google e gli archivi storici sono esclusi; i relativi avvii richiedono una configurazione separata. Non pubblicare questa anteprima senza completare i punti di produzione indicati.
